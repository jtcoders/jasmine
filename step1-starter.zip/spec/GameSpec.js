// Here is where your tests will go.

// write a test describing the function called moveRight

// write a test describing the function called moveLeft

// write a test describing the function called moveDown

// write a test describing the function called moveUp